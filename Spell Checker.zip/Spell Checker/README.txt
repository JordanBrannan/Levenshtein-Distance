Within the LevenshteinSpellCheck class, the input.txt, dictionary.txt and output.txt
need to be updated with the location that these are stored.

- Jordan